package com.kaushik.person.impl;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kaushik.person.bean.Address;
import com.kaushik.person.bean.Person;
import com.kaushik.person.exception.ResourceNotFoundException;
import com.kaushik.person.repo.AddressRepository;
import com.kaushik.person.repo.PersonRepository;
@Service
public class PersonServiceImpl {
	
	@Autowired
	PersonRepository prepo;
	
	@Autowired
	AddressRepository addRepo;

	public Person savePersion(Person person) {
		Set<Address> addr=person.getAddress();
		Person p= prepo.save(person);
		p.setAddress(null);
		long count=0;
		if(p !=null) {
			count=addRepo.count();
			for(Address ar:addr) {
				long id=count+1;
				ar.setPerson(p);
				ar.setId(id);
				addRepo.save(ar);
			}
		}
		return p;
	}

	public List<Person> getPersonList() {
		
		return (List<Person>) prepo.findAll();
	}
	
	public Person getPersonById(long id) {
		Person po=prepo.findById(id).orElse(null);
		List<Address> addrlst=addRepo.findByPersonId(id);
		Set<Address> paddr=addrlst.stream().collect(Collectors.toSet());
		po.setAddress(paddr);
		return po;
		
	}

	public ResponseEntity<Object> deletePersonById(long id) {
		
		return prepo.findById(id).map(p -> {
            prepo.deleteById(id);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("PersonId " + id + " not found"));
	}
	
	
	public Person find(long id) {
		return prepo.findById(id).orElse(null);
	}

	public Person updatePerson(Person po) {
		Person exist=prepo.findById(po.getId()).orElse(null);
		if(exist !=null) {
			exist.setFirstName(po.getFirstName());
			exist.setLastName(po.getLastName());
			exist=prepo.save(exist);
		}
		return exist;
	}
	

}

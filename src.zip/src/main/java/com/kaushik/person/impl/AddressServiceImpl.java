package com.kaushik.person.impl;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kaushik.person.bean.Address;
import com.kaushik.person.exception.ResourceNotFoundException;
import com.kaushik.person.repo.AddressRepository;
@Service
public class AddressServiceImpl {
	
	@Autowired
	private AddressRepository addrRepo;
	
	
	public List<Address> getAddrByUserId(long pid){
		
		List<Address> addressLst= ((Collection<Address>) addrRepo.findAll()).stream()
				.filter(addr -> addr.getPerson().getId() == pid).collect(Collectors.toList());
		return addressLst;
	}
	
	public Address createNew(Address addr) {
		return addrRepo.save(addr);
	}
	
	public Address updateAddr(Address addr) {
		Address adr=addrRepo.findById(addr.getId()).orElse(null);
		adr.setCity(addr.getCity());
		adr.setState(addr.getState());
		adr.setStreet(addr.getStreet());
		adr.setPostalCode(adr.getPostalCode());
		Address newaddr=null;
		try {
			newaddr = addrRepo.save(adr);
		} catch (Exception e) {
			System.out.println("error in update operation"+e.getMessage());
		}
		return newaddr;
		
	}

	public ResponseEntity<?> deleteAddressById(long id) {
		return addrRepo.findById(id).map(p -> {
			addrRepo.deleteById(id);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Address Id " + id + " not found"));
	}

	public Address findByAddressId(Long id) {
		
		return addrRepo.findById(id).orElse(null);
	}

}

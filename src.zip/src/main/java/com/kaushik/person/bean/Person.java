package com.kaushik.person.bean;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="person")
public class Person {
	
   @Id
   @GeneratedValue(strategy =GenerationType.SEQUENCE,generator = "person_generator")
   @SequenceGenerator(name="person_generator", sequenceName = "person_seq", allocationSize=1)
   private long id;
   private String firstName;
   private String lastName;
   
    @OneToMany(mappedBy = "id", fetch = FetchType.EAGER, cascade = {CascadeType.MERGE})
	private Set<Address> address;
      
   public Person() {
		
	}
   public Person(long id, String firstName, String lastName) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
	}
   public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Set<Address> getAddress() {
		return address;
	}
	public void setAddress(Set<Address> address) {
		this.address = address;
	}

	
   
   
	
}

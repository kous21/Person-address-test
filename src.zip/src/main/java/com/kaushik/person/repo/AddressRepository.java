package com.kaushik.person.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.kaushik.person.bean.Address;

public interface AddressRepository extends CrudRepository<Address, Long> {
	
	@Query(value="select * from address a where a.person_id = :pid", nativeQuery = true)
	public List<Address> findByPersonId(long pid);

}

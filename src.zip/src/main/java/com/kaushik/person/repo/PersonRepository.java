package com.kaushik.person.repo;

import org.springframework.data.repository.CrudRepository;

import com.kaushik.person.bean.Person;


public interface PersonRepository extends CrudRepository<Person, Long> {

}

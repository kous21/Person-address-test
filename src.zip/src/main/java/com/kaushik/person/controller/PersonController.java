package com.kaushik.person.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kaushik.person.bean.Person;
import com.kaushik.person.impl.PersonServiceImpl;

@RestController
@RequestMapping("/api/person/")
public class PersonController {
	
	@Autowired
	PersonServiceImpl personImpl;
	
	@GetMapping("/{id}")
	public Person getById(@PathVariable(value = "id") long id) {
		return personImpl.getPersonById(id);
	}
	
	@GetMapping("/list")
	public List<Person> listofperson(){
		List<Person> plist= new ArrayList<>();
		plist=personImpl.getPersonList();
		
		return plist;
	}
	
	@PostMapping("/create")
	public Person createPerson(@RequestBody Person person) {
		  Person p=new Person();
		if(person !=null) {
			p=personImpl.savePersion(person);
		}
		return p;
	}
	
	@PutMapping("/update")
	public String updatePerson(@RequestBody Person po) {
		try {
			Person person = personImpl.updatePerson(po);

			if (person != null) {
				return "Person Updated Succesfully";
			} else {
				return "Error trying to update Person.";
			}
		} catch (Exception e) {
			
			return "Error trying to update person."+e.getMessage();
		}
		
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable(value = "id") long id){
		
		return personImpl.deletePersonById(id);
		
		
	}
	
	
	
	

}

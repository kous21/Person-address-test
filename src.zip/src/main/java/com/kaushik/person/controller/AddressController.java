package com.kaushik.person.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kaushik.person.bean.Address;
import com.kaushik.person.impl.AddressServiceImpl;

@RestController
@RequestMapping("/api/address/")
public class AddressController {
	
	@Autowired
	private AddressServiceImpl addrs;
	
	@GetMapping("/{id}")
	private Address FindAddressId(@PathVariable(value = "id") Long id){
		return addrs.findByAddressId(id);
	}
	
	@GetMapping("/list/{pid}")
	private List<Address> listByPersonId(@PathVariable(value = "personid") Long pid){
		return addrs.getAddrByUserId(pid);
	}
	
	@PutMapping("/update/{id}")
	public Address updateAddr(Address addr) {
		
		return addrs.updateAddr(addr);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteAddr(@PathVariable(value="id") long id){
		
		return addrs.deleteAddressById(id);
	}
	

}

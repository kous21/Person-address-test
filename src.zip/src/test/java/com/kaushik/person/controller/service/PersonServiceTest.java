package com.kaushik.person.controller.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.kaushik.person.bean.Person;
import com.kaushik.person.impl.PersonServiceImpl;
import com.kaushik.person.repo.PersonRepository;

@ExtendWith(MockitoExtension.class)
public class PersonServiceTest {
	
	@Mock
    private PersonRepository personRepository;

    @InjectMocks
    private PersonServiceImpl personService;
    
    
    @Test
    void shouldSavedPersonSuccessFully() {
        final Person person = new Person();
        person.setFirstName("koushik");
        person.setLastName("nandy");

        given(personRepository.findById(person.getId())).willReturn(null);
        given(personRepository.save(person)).willAnswer(invocation -> invocation.getArgument(0));

        Person savedPerson = personService.savePersion(person);

        assertThat(savedPerson).isNotNull();

        verify(personRepository).save(person);

    }
    
    
   

    @Test
    void shouldReturnFindAll() {
        List<Person> datas = new ArrayList<>();
        datas.add(new Person(1L, "teten","teten"));
        datas.add(new Person(2L,"teten","teten"));
        datas.add(new Person(3L, "teten","teten"));

        given(personRepository.findAll()).willReturn(datas);

        List<Person> expected = personService.getPersonList();

        assertEquals(expected, datas);
    }



}

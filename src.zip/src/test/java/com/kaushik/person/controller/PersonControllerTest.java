package com.kaushik.person.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import com.kaushik.person.bean.Person;
import com.kaushik.person.impl.PersonServiceImpl;

@WebMvcTest(controllers = PersonController.class)
@ActiveProfiles("test")
public class PersonControllerTest {
	@Autowired
    private MockMvc mockMvc;

    @MockBean
    private PersonServiceImpl personService;
    
    private List<Person> personList;
    
    @BeforeEach
    void setUp() {
        this.personList = new ArrayList<>();
        this.personList.add(new Person(1L, "abc", "xyz"));
        this.personList.add(new Person(2L, "ddd", "xyz"));
        this.personList.add(new Person(3L, "rrr", "xyz"));

    }
    
    @Test
    void shouldFetchAllPersons() throws Exception {

        given(personService.getPersonList()).willReturn(personList);

        this.mockMvc.perform(get("/api/person/list"));
               // .andExpect(status().isOk());
               // .andExpect(jsonPath("$.size()"), personList.size());
    }

    @Test
    void shouldFetchOnePersonById() throws Exception {
        final Long pId = 1L;
        final Person user = new Person(1L, "teten","teten");

        given(personService.getPersonById(pId)).willReturn(user);

        this.mockMvc.perform(get("/api/person/{id}", pId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("teten", is(user.getLastName())))
                .andExpect(jsonPath("teten", is(user.getFirstName())));
    }
    
    @Test
    void shouldReturn404WhenFindPersonById() throws Exception {
        final Long pId = 1L;
        given(personService.find(pId)).willReturn(null);

        this.mockMvc.perform(get("/api/user/{id}", pId))
                .andExpect(status().isNotFound());
    }

    
    
    @Test
    void shouldCreateNewPerson() throws Exception {
       

        Person person = new Person();
        given(personService.savePersion(person)).willAnswer((invocation) -> invocation.getArgument(0));

        this.mockMvc.perform(post("/api/person")
                .contentType(MediaType.APPLICATION_JSON)
                .content(person.toString()))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.firstName", is(person.getFirstName())))
                .andExpect(jsonPath("$.lastName", is(person.getLastName())))
                //.andExpect(jsonPath("$.name", is(person.getName())))
        ;
    }
    @SuppressWarnings("deprecation")
	@Test
    void shouldUpdateUser() throws Exception {
        Long pId = 1L;
        Person person = new Person(pId, "pwd", "Name");
        given(personService.find(pId)).willReturn(person);
        given(personService.updatePerson(person)).willAnswer((invocation) -> invocation.getArgument(0));

        this.mockMvc.perform(put("/api/person/{id}", person.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(person.toString()));
                //.andExpect(status().isOk())
                //.andExpect(jsonPath("$.firstName", is(person.getFirstName())))
                //.andExpect(jsonPath("$.lastName", is(person.getLastName())));

    }

}
